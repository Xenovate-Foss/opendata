const { 
    Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionsBitField, 
    ActionRowBuilder, StringSelectMenuBuilder, ChannelType , ButtonBuilder, ButtonStyle
} = require('discord.js');
const dotenv = require('dotenv');
const fs = require("fs");

dotenv.config();
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessageReactions
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction]
});

const tickets = new Map(); // Store active tickets
const categoriesPath = "./categories.json";
let categoriesList = loadCategories(); // Load categories at startup

client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
});

// Interaction Handler
client.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
        if (interaction.customId.startsWith("create_ticket_")) {
            const categoryName = interaction.customId.replace("create_ticket_", "");
            await createTicket(interaction, categoryName);
        } else if (interaction.customId === 'close_ticket_confirm') {
            await closeTicketConfirm(interaction);
        } else if (interaction.customId === 'claim_ticket') {
            await claimTicket(interaction);
        } else if (interaction.customId === 'close_ticket_yes') {
            await closeTicket(interaction);
        } else if(interaction.customId === 'close_ticket_no') {
            await closeTicketNo(interaction) 
        }
    } else if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'ticket_category_select') {
            const categoryName = interaction.values[0]; // Get selected category
            await createTicket(interaction, categoryName);
        }
    } else if (interaction.isCommand()) {
        if (interaction.commandName === 'setup') {
            await setupTicketSystem(interaction);
        } else if (interaction.commandName === 'adduser') {
            await addUserToTicket(interaction);
        } else if (interaction.commandName === 'addcategory') {
            await addCategory(interaction);
        } else if (interaction.commandName === 'close') {
            await closeTicketConfirm(interaction);
        }
    }
});
// close ticket confirm
async function closeTicketConfirm(interaction) {
    const channel = interaction.channel;
    if (!channel) return;
    const embed = new EmbedBuilder()
        .setTitle("Close Ticket Confirm")
        .setDescription("Do you really want to close this ticket? Click 'Yes' to confirm or 'No' to cancel.")
        .setColor("Green");

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('close_ticket_no').setLabel('❌ No').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('close_ticket_yes').setLabel('🔒 Yes').setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: false });
}
// close ticket no
async function closeTicketNo(interaction) {
await interaction.message.delete();
}

// Close Ticket (Fix added here)
async function closeTicket(interaction) {
    const channel = interaction.channel;
    if (!channel) return;

    await interaction.reply({ content: "🔒 Closing ticket...", ephemeral: true });
    setTimeout(() => channel.delete(), 3000);
    const embeds = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`Ticket Closed ${channel}`)
                      .setDescription(`The ticket named ${channel} has been closed by ${interaction.member}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});
    await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
    tickets.delete(interaction.user.id);
}

// Claim Ticket (Fix added here)
async function claimTicket(interaction) {
    const member = interaction.member;
    const channel = interaction.channel;

    if (!channel || !member) return;

    await interaction.reply({ content: `👨‍💼 Ticket claimed by ${member}.`, ephemeral: false });
    const embed = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`Ticket Claimed ${channel}`)
                      .setDescription(`The ticket called ${channel} has been claimed by ${member}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});

    client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embed]});
}

async function addUserToTicket(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ You don't have permission to do this!", ephemeral: true  })
    }
    const channel = interaction.channel;
    const user = interaction.options.getUser("user");

    if (!user) {
        return interaction.reply({ content: "❌ Please mention a valid user.", ephemeral: true });
    }

    try {
        await channel.permissionOverwrites.edit(user.id, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true
        });

        const embed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle("User Added to Ticket")
            .setDescription(`✅ **${user.username}** has been added to this ticket.`)
            .setTimestamp()
            .setFooter({ text: "Support System", iconURL: user.displayAvatarURL() });

        await channel.send({ embeds: [embed] });
        const embeds = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`Ticket User Added ${channel}`)
                      .setDescription(`The ticket named ${channel} had one more member added ${user}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});
        await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
        await interaction.reply({ content: `✅ **${user.username}** has been added to this ticket.`, ephemeral: true });
    } catch (error) {
        console.error(`❌ Failed to add ${user.username} to ticket:`, error);
        await interaction.reply({ content: "❌ Failed to add user to the ticket.", ephemeral: true });
    }
}

// Kick User
async function kickUserFromTicket(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ You don't have permission to do this!", ephemeral: true  })
    }
    const channel = interaction.channel;
    const user = interaction.options.getUser("user");

    if (!user) {
        return interaction.reply({ content: "❌ Please mention a valid user.", ephemeral: true });
    }

    try {
        await channel.permissionOverwrites.edit(user.id, {
            ViewChannel: false,
            SendMessages: false,
            ReadMessageHistory: false
        });

        const embed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle("User Kicked from Ticket")
            .setDescription(`✅ **${user.username}** has been kicked from this ticket.`)
            .setTimestamp()
            .setFooter({ text: "Support System", iconURL: user.displayAvatarURL() });

        await channel.send({ embeds: [embed] });
        const embeds = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`Ticket User kicked ${channel}`)
                      .setDescription(`The ticket named ${channel} had kicked member named ${user}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});
        await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
        await interaction.reply({ content: `✅ **${user.username}** has been added to this ticket.`, ephemeral: true });
    } catch (error) {
        console.error(`❌ Failed to add ${user.username} to ticket:`, error);
        await interaction.reply({ content: "❌ Failed to add user to the ticket.", ephemeral: true });
    }
}


// Setup Ticket Panel
async function setupTicketSystem(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ You don't have permission to do this!", ephemeral: true });
    }

    if (!categoriesList.length) {
        return interaction.reply({ content: "❌ No categories found. Please add categories first.", ephemeral: true });
    }

    // Create the Select Menu (Dropdown)
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_category_select')
        .setPlaceholder('Select a category')
        .addOptions(
            categoriesList.slice(0, 25).map(category => ({
                label: category.name,
                value: category.name,
                description: category.description,
                emoji: category.emoji
            }))
        );

    const row = new ActionRowBuilder().addComponents(selectMenu);
    const embed = new EmbedBuilder()
    .setTitle("If you need any assistance, choose the corresponding option for the type of ticket you wish to open.")
    .setDescription(
        "**📘 1. Please follow the rules**\n" +
        "**🚫 2. Making a ticket for fun and time pass may result in a blacklist from ticket creation.**\n" +
        "**📞 3. Please be patient, our staff are humans and will assist you as soon as possible.**\n" +
        "**📝 4. Please be respectful to moderators, we have the whole conversation recorded.**"
    )
    .addFields({
        name: "⚠️ __**Important Notice**__ ⚠️",
        value: "__**After reading the guidelines, only then open a ticket!**__",
    })
    .setFooter({ 
        text: "Crinix Cloud Support",  
        iconURL: "https://cdn.discordapp.com/icons/1331603096274604124/b6f2e24c9d2f411e93df9b61ee73b0f4.png"
    })
    .setColor("Blue");

    await interaction.deferReply({ ephemeral: true });
    await interaction.channel.send({ embeds: [embed], components: [row] });
    await interaction.editReply({ content: "✅ Ticket panel created!" });

    const embeds = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle(`Ticket Panel Set to ${interaction.channel.name}`)
        .setDescription(`The ticket panel has been set in this channel: ${interaction.channel.toString()}`)
        .setTimestamp()
        .setFooter({ text: "Crinic cloud ticket logger"});

    await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
}

// Create Ticket
async function createTicket(interaction, categoryName) {
    const user = interaction.user;

    if (tickets.has(user.id)) {
        return interaction.reply({ content: "❌ You already have an open ticket.", ephemeral: true });
    }

    const category = categoriesList.find(cat => cat.name === categoryName);
    const channel = await interaction.guild.channels.create({
        name: `ticket-${user.username}`,
        type: ChannelType.GuildText,
        parent: category ? category.id : process.env.CATEGORY_ID,
        permissionOverwrites: [
            { id: process.env.GUILD_ID, deny: [PermissionsBitField.Flags.ViewChannel] },
            { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
            { id: process.env.SUPPORT_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel] }
        ]
    });

    tickets.set(user.id, channel.id);

    const embed = new EmbedBuilder()
        .setTitle("🎟 Ticket Created")
        .setDescription(`Hello ${user}, a staff member will assist you soon. \n <@&${process.env.SUPPORT_ROLE_ID}>`)
        .setColor("Green");

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('claim_ticket').setLabel('👨‍💼 Claim Ticket').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('close_ticket_confirm').setLabel('🔒 Close Ticket').setStyle(ButtonStyle.Danger)
    );

    await channel.send({ content: `<@${user.id}>`, embeds: [embed], components: [row] });
    interaction.reply({ content: `✅ Ticket created: <#${channel.id}>`, ephemeral: true });

    const embeds = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`New Ticket Created ${channel}`)
                      .setDescription(`The ticket named ${channel} has been created by ${user}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});
    await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
}

// Add Category Command
async function addCategory(interaction) {
    const name = interaction.options.getString("name");
    const description  = interaction.options.getString("description");
    const emoji = interaction.options.getString("emoji") || "🔵";

    if (!name || name.trim() === "") {
        return interaction.reply({ content: "❌ Please provide a valid category name.", ephemeral: true });
    }

    if (categoriesList.some(category => category.name === name)) {
        return interaction.reply({ content: `❌ Category **${name}** already exists.`, ephemeral: true });
    }

    try {
        const categoryChannel = await interaction.guild.channels.create({
            name,
            type: ChannelType.GuildCategory,
        });

        const newCategory = { name, id: categoryChannel.id, description, emoji };
        categoriesList.push(newCategory);
        saveCategories(categoriesList);

        interaction.reply({ content: `✅ Category **${name}** added with description   **${description}**.`, ephemeral: true });
    } catch (error) {
        console.error(error);
        interaction.reply({ content: `❌ Failed to create category: ${error.message}`, ephemeral: true });
    }

    const embeds = new EmbedBuilder()
                      .setColor(0x00ff00)
                      .setTitle(`New Ticket Category Added`)
                      .setDescription(`New Ticket Category added named:  ${name}`)
                      .setTimestamp()
                      .setFooter({ text: "Crinic cloud ticket logger"});
    await client.channels.cache.get(process.env.LOG_CHANNEL_ID).send({embeds: [embeds]});
}

// Load & Save Categories
function loadCategories() {
    try {
        if (fs.existsSync(categoriesPath)) {
            return JSON.parse(fs.readFileSync(categoriesPath, "utf8"));
        }
    } catch (error) {
        console.error("❌ Error loading categories.json:", error);
    }
    return [];
}

function saveCategories(categories) {
    try {
        fs.writeFileSync(categoriesPath, JSON.stringify(categories, null, 4));
    } catch (error) {
        console.error("❌ Error saving categories.json:", error);
    }
}

client.login(process.env.TOKEN);