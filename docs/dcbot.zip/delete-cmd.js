const { REST, Routes } = require('discord.js');
require('dotenv').config();

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

async function deleteAllGlobalCommands() {
    try {
        console.log("Deleting all global commands...");
        await rest.put(Routes.applicationCommands(process.env.BOT_ID), { body: [] });
        console.log("✅ All global commands deleted.");
    } catch (error) {
        console.error("Error deleting global commands:", error);
    }
}

deleteAllGlobalCommands();
