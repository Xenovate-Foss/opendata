const fs = require('fs');
const { ChannelType } = require('discord.js');
const categoriesList = require('./categories.json'); // Assuming the categories are stored in categories.json

// Helper function to save categories to JSON
function saveCategories(categories) {
    fs.writeFileSync('categories.json', JSON.stringify(categories, null, 2));
}

// Add Category
async function addCategory(interaction) {
    const name = interaction.options.getString("name");
    const priority = interaction.options.getString("description");
    const color = interaction.options.getString("emoji") || "🔵"; 

    if (!name || name.trim() === "") {
        return interaction.reply({ content: "❌ Please provide a valid category name.", ephemeral: true });
    }

    if (categoriesList.some(category => category.name === name)) {
        return interaction.reply({ content: `❌ Category **${name}** already exists.`, ephemeral: true });
    }

    try {
        const categoryChannel = await interaction.guild.channels.create({
            name,
            type: ChannelType.GuildCategory,
        });

        const newCategory = { name, id: categoryChannel.id, priority, color };
        categoriesList.push(newCategory);
        saveCategories(categoriesList);

        interaction.reply({ content: `✅ Category **${name}** added with priority **${priority}**.`, ephemeral: true });
        logAction("New Ticket Category Added", `New ticket category added named: ${name}`);
    } catch (error) {
        console.error(error);
        interaction.reply({ content: `❌ Failed to create category: ${error.message}`, ephemeral: true });
    }
}

// Remove Category
async function removeCategory(interaction) {
    const name = interaction.options.getString("name");

    if (!name || name.trim() === "") {
        return interaction.reply({ content: "❌ Please provide a valid category name to remove.", ephemeral: true });
    }

    const categoryIndex = categoriesList.findIndex(category => category.name === name);
    if (categoryIndex === -1) {
        return interaction.reply({ content: `❌ No category found with the name **${name}**.`, ephemeral: true });
    }

    try {
        // Delete category channel
        const categoryId = categoriesList[categoryIndex].id;
        const categoryChannel = await interaction.guild.channels.fetch(categoryId);
        await categoryChannel.delete();

        // Remove category from the list
        categoriesList.splice(categoryIndex, 1);
        saveCategories(categoriesList);

        interaction.reply({ content: `✅ Category **${name}** removed successfully.`, ephemeral: true });
        logAction("Ticket Category Removed", `The ticket category named ${name} has been removed.`);
    } catch (error) {
        console.error(error);
        interaction.reply({ content: `❌ Failed to remove category: ${error.message}`, ephemeral: true });
    }
}