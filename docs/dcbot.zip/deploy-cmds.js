const { REST, Routes, SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

const commands = [
    new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup ticket panel (Admin only).'),
    new SlashCommandBuilder()
         .setName("close")
         . setDescription("Close this ticket for ever"),
    
    new SlashCommandBuilder()
        .setName('adduser')
        .setDescription('Add a user to the ticket.')
        .addUserOption(option => 
            option.setName('user')
            .setDescription('User to add')
            .setRequired(true)),

    new SlashCommandBuilder()
        .setName('kickuser')
        .setDescription('kick a user from the ticket.')
        .addUserOption(option => 
            option.setName('user')
            .setDescription('User to add')
            .setRequired(true)),

    new SlashCommandBuilder()
        .setName('addcategory')
        .setDescription('Add a new ticket category.')
        .addStringOption(option => 
            option.setName('name')
            .setDescription('Category name')
            .setRequired(true))
        .addStringOption(option => 
            option.setName('description') // Changed to lowercase
            .setDescription('The description of the ticket category')
            .setRequired(true))
        .addStringOption(option => 
            option.setName('emoji') // Changed to lowercase
            .setDescription('The emoji for the ticket category')
            .setRequired(false)),

    new SlashCommandBuilder()
        .setName('removecategory')
        .setDescription('Remove an existing ticket category.')
        .addStringOption(option => 
            option.setName('name')
            .setDescription('Category name to remove')
            .setRequired(true))
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

async function registerCommands() {
    try {
        console.log("Registering commands...");
        await rest.put(Routes.applicationCommands(process.env.BOT_ID), { body: commands });
        console.log("✅ Commands registered.");
    } catch (error) {
        console.error(error);
    }
}

registerCommands();